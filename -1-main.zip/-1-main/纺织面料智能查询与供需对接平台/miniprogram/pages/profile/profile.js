// pages/profile/profile.js
var request = require('../../utils/request');
var auth = require('../../utils/auth');

var ROLE_TEXT_MAP = {
  'buyer': '采购方',
  'supplier': '供应商',
  'admin': '管理员'
};

var CERT_STATUS_MAP = {
  'pending': '待认证',
  'approved': '已认证',
  'rejected': '认证未通过'
};

Page({
  data: {
    loading: false,
    isLoggedIn: false,
    isEditing: false,
    saving: false,
    userInfo: null,
    roleText: '',
    certStatusText: '',
    avatarLetter: '',
    editForm: {
      company_name: '',
      contact_name: '',
      address: ''
    }
  },

  onLoad: function () {
    this._checkLoginAndLoad();
  },

  onShow: function () {
    var that = this;
    // 延迟检查避免渲染层未就绪时 setData 报警告
    setTimeout(function () {
      that._checkLoginAndLoad();
    }, 50);
  },

  onPullDownRefresh: function () {
    if (this.data.isLoggedIn) {
      this._fetchProfile(function () {
        wx.stopPullDownRefresh();
      });
    } else {
      wx.stopPullDownRefresh();
    }
  },

  _checkLoginAndLoad: function () {
    var token = wx.getStorageSync('token') || '';
    var userInfo = wx.getStorageSync('userInfo') || null;

    console.log('[profile] _checkLoginAndLoad, token:', token ? 'exists(' + token.substring(0, 10) + '...)' : 'EMPTY');
    console.log('[profile] _checkLoginAndLoad, userInfo:', userInfo ? JSON.stringify(userInfo).substring(0, 60) : 'NULL');

    if (!token) {
      var app = getApp();
      if (app && app.globalData && app.globalData.token) {
        token = app.globalData.token;
        userInfo = app.globalData.userInfo;
        console.log('[profile] fallback to globalData, token:', token ? 'exists' : 'EMPTY');
      }
    }

    if (!token) {
      console.log('[profile] no token found, showing login state');
      this.setData({
        loading: false,
        isLoggedIn: false,
        userInfo: null
      });
      return;
    }

    console.log('[profile] token found, setting isLoggedIn=true');
    this.setData({ isLoggedIn: true });

    if (userInfo) {
      this._setUserData(userInfo);
    }

    this._fetchProfile();
  },

  _fetchProfile: function (callback) {
    var that = this;
    this.setData({ loading: true });

    request.get('/auth/profile').then(function (res) {
      var user = res.user || {};
      wx.setStorageSync('userInfo', user);
      that._setUserData(user);
      that.setData({ loading: false });
      if (callback) callback();
    }).catch(function () {
      that.setData({ loading: false });
      if (callback) callback();
    });
  },

  _setUserData: function (user) {
    var roleText = ROLE_TEXT_MAP[user.role] || '';
    var certStatus = user.certification_status || '';
    var certStatusText = CERT_STATUS_MAP[certStatus] || '';
    var avatarLetter = '用';
    
    if (user.contact_name) {
      avatarLetter = user.contact_name.charAt(0);
    } else if (user.company_name) {
      avatarLetter = user.company_name.charAt(0);
    } else if (user.phone) {
      avatarLetter = user.phone.charAt(0);
    }

    this.setData({
      userInfo: user,
      roleText: roleText,
      certStatusText: certStatusText,
      avatarLetter: avatarLetter,
      editForm: {
        company_name: user.company_name || '',
        contact_name: user.contact_name || '',
        address: user.address || ''
      }
    });
  },

  toggleEdit: function () {
    this.setData({ isEditing: !this.data.isEditing });
  },

  onCompanyInput: function (e) {
    this.setData({ 'editForm.company_name': e.detail.value });
  },

  onContactInput: function (e) {
    this.setData({ 'editForm.contact_name': e.detail.value });
  },

  onAddressInput: function (e) {
    this.setData({ 'editForm.address': e.detail.value });
  },

  saveProfile: function () {
    var that = this;
    var form = this.data.editForm;

    this.setData({ saving: true });

    request.put('/auth/profile', {
      company_name: form.company_name,
      contact_name: form.contact_name,
      address: form.address
    }).then(function (res) {
      var updatedUser = res.user || {};
      wx.setStorageSync('userInfo', updatedUser);
      that._setUserData(updatedUser);
      that.setData({ saving: false, isEditing: false });
      wx.showToast({ title: '保存成功', icon: 'success' });
    }).catch(function () {
      that.setData({ saving: false });
    });
  },

  onAvatarTap: function () {
    wx.showToast({ title: '头像功能开发中', icon: 'none' });
  },

  goLogin: function () {
    console.log('[profile] goLogin called');
    wx.navigateTo({ url: '/pages/login/login' });
  },

  goToFavorites: function () {
    wx.navigateTo({ url: '/pages/favorites/favorites' });
  },

  goToOrders: function () {
    wx.navigateTo({ url: '/pages/order/list/list' });
  },

  goToSamples: function () {
    wx.navigateTo({ url: '/pages/sample/sample' });
  },

  goToDemands: function () {
    wx.navigateTo({ url: '/pages/demand/list/list' });
  },

  goToFabrics: function () {
    wx.switchTab({ url: '/pages/fabric/list/list' });
  },

  goPublishFabric: function () {
    wx.navigateTo({ url: '/pages/fabric/publish/publish' });
  },

  goManageFabrics: function () {
    wx.navigateTo({ url: '/pages/fabric/manage/manage' });
  },

  goToAudit: function () {
    wx.showToast({ title: '审核功能开发中', icon: 'none' });
  },

  goToStats: function () {
    wx.showToast({ title: '统计功能开发中', icon: 'none' });
  },

  goToAbout: function () {
    wx.showModal({
      title: '关于平台',
      content: '纺织面料智能查询与供需对接平台 v1.0.0',
      showCancel: false
    });
  },

  handleLogout: function () {
    var that = this;
    wx.showModal({
      title: '提示',
      content: '确定要退出登录吗？',
      confirmText: '退出',
      success: function (res) {
        if (res.confirm) {
          auth.clearToken();
          that.setData({
            isLoggedIn: false,
            userInfo: null,
            isEditing: false
          });
          wx.showToast({ title: '已退出登录', icon: 'success' });
        }
      }
    });
  }
});
